package com.freemoney.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(8,13,10), CARD=Color.rgb(19,29,22), GREEN=Color.rgb(57,231,95), WHITE=Color.WHITE, MUTED=Color.rgb(170,185,174);
    private android.content.SharedPreferences prefs;
    private LinearLayout root, body;
    private String adUrl;
    private int points;
    private String username;

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("free_money",MODE_PRIVATE); points=prefs.getInt("points",0); username=prefs.getString("username",""); adUrl=prefs.getString("ad_url","https://example.com"); if(username.isEmpty()) askName(); show("Home"); }
    private void askName(){ EditText e=new EditText(this); e.setHint("আপনার নাম লিখুন"); new AlertDialog.Builder(this).setTitle("Free Money-তে স্বাগতম").setMessage("ডেমো প্রোফাইল তৈরি করতে নাম লিখুন").setView(e).setCancelable(false).setPositiveButton("শুরু করুন",(d,w)->{username=e.getText().toString().trim(); if(username.isEmpty()) username="User"; prefs.edit().putString("username",username).apply(); show("Home");}).show(); }
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); t.setPadding(0,5,0,5); return t; }
    private GradientDrawable bg(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
    private LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void pad(View v,int p){v.setPadding(p,p,p,p);} 
    private void show(String page){
        root=column(); root.setBackgroundColor(BG); setContentView(root);
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(20,18,20,18);
        TextView brand=text("◈  FREE MONEY",22,GREEN,true); header.addView(brand,new LinearLayout.LayoutParams(0,-2,1)); header.addView(text("● DEMO",11,MUTED,true)); root.addView(header);
        ScrollView scroll=new ScrollView(this); body=column(); body.setPadding(18,8,18,24); scroll.addView(body); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(page.equals("Home")) home(); else if(page.equals("Tasks")) tasks(); else if(page.equals("Wallet")) wallet(); else if(page.equals("Messages")) messages(); else settings();
        LinearLayout nav=new LinearLayout(this); nav.setBackgroundColor(CARD); String[] tabs={"Home","Tasks","Wallet","Messages","Settings"}; for(String tab:tabs){ TextView b=text(tab,11,page.equals(tab)?GREEN:WHITE,true); b.setGravity(Gravity.CENTER); b.setPadding(2,16,2,16); nav.addView(b,new LinearLayout.LayoutParams(0,-2,1)); b.setOnClickListener(v->show(tab)); } root.addView(nav);
    }
    private void card(String title,String desc){ LinearLayout c=column(); c.setBackground(bg(CARD,22)); c.setPadding(18,14,18,14); TextView h=text(title,18,WHITE,true); c.addView(h); c.addView(text(desc,14,MUTED,false)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; body.addView(c,lp); }
    private void button(String label,Runnable action){ TextView b=text(label,15,BG,true); b.setGravity(Gravity.CENTER); b.setPadding(16,14,16,14); b.setBackground(bg(GREEN,16)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=10; body.addView(b,lp); b.setOnClickListener(v->action.run()); }
    private void home(){ body.addView(text("হ্যালো, "+username+" 👋",23,WHITE,true)); body.addView(text("আপনার Free Money ড্যাশবোর্ডে স্বাগতম",14,MUTED,false));
        LinearLayout c=column(); c.setBackground(bg(0xff10351b,24)); c.setPadding(20,20,20,20); c.addView(text("YOUR REWARD POINTS",12,0xffB6F7C4,true)); c.addView(text(String.valueOf(points)+" Points",34,GREEN,true)); c.addView(text("এগুলো ডেমো নন-ক্যাশ পয়েন্ট; নগদ অর্থ নয়।",12,WHITE,false)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,18,0,18); body.addView(c,lp);
        card("Daily Tasks","ছোট ছোট কাজ সম্পন্ন করে ডেমো পয়েন্ট সংগ্রহ করুন।"); button("আজকের Task দেখুন",()->show("Tasks")); card("Watch Sponsor","স্পনসর লিংক খুলুন। বিজ্ঞাপন দেখা বা ক্লিকের জন্য পয়েন্ট স্বয়ংক্রিয়ভাবে যোগ হয় না।"); button("Sponsor Website খুলুন",()->openAd()); card("Invite Friends","আপনার বন্ধুদের Free Money সম্পর্কে জানান। রেফারেল ট্র্যাকিং সার্ভার সংযুক্ত হলে চালু হবে।");
    }
    private void tasks(){ body.addView(text("Daily Tasks",24,WHITE,true)); body.addView(text("এটি লোকাল ডেমো। প্রতিটি কাজ একবার করে পয়েন্ট দেয়।",13,MUTED,false)); task("প্রোফাইল সম্পূর্ণ করুন",10,"profile"); task("অ্যাপের নিয়ম পড়ুন",5,"rules"); task("বন্ধুকে অ্যাপ সম্পর্কে জানান",15,"invite"); }
    private void task(String title,int reward,String key){ LinearLayout c=column(); c.setBackground(bg(CARD,18)); c.setPadding(16,14,16,14); c.addView(text(title,17,WHITE,true)); c.addView(text("Reward: "+reward+" points",13,GREEN,true)); String done=prefs.getBoolean("task_"+key,false)?"Completed ✓":"Complete Task"; TextView b=text(done,14,BG,true); b.setGravity(Gravity.CENTER); b.setPadding(12,10,12,10); b.setBackground(bg(GREEN,14)); c.addView(b); b.setOnClickListener(v->{if(!prefs.getBoolean("task_"+key,false)){points+=reward;prefs.edit().putInt("points",points).putBoolean("task_"+key,true).apply(); Toast.makeText(this,"ডেমো পয়েন্ট যোগ হয়েছে",Toast.LENGTH_SHORT).show(); show("Tasks");}else Toast.makeText(this,"এই কাজটি আগেই সম্পন্ন",Toast.LENGTH_SHORT).show();}); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; body.addView(c,lp); }
    private void wallet(){ body.addView(text("My Wallet",24,WHITE,true)); card("Available Points",points+" Points"); card("Cash Withdrawal","নগদ উত্তোলন এখনো চালু নয়। পয়েন্টের কোনো নগদ মূল্য নির্ধারিত নেই।"); card("Points History","ডেমোতে অর্জিত পয়েন্ট ডিভাইসেই সংরক্ষিত হয়।"); }
    private void messages(){ body.addView(text("Messages",24,WHITE,true)); body.addView(text("অ্যাডমিনকে মেসেজ পাঠান (ডেমো)",14,MUTED,false)); EditText msg=new EditText(this); msg.setHint("আপনার মেসেজ লিখুন"); msg.setTextColor(WHITE); msg.setHintTextColor(MUTED); msg.setMinLines(3); msg.setGravity(Gravity.TOP); msg.setBackground(bg(CARD,14)); msg.setPadding(14,14,14,14); body.addView(msg); button("মেসেজ সংরক্ষণ করুন",()->{String s=msg.getText().toString().trim(); if(s.isEmpty()){Toast.makeText(this,"মেসেজ লিখুন",Toast.LENGTH_SHORT).show();return;} prefs.edit().putString("last_message",s).apply(); Toast.makeText(this,"মেসেজ এই ডিভাইসে সংরক্ষিত হয়েছে; অ্যাডমিনে পাঠানো হয়নি",Toast.LENGTH_LONG).show(); msg.setText("");}); String last=prefs.getString("last_message",""); if(!last.isEmpty()) card("Last saved message",last); }
    private void settings(){ body.addView(text("Settings",24,WHITE,true)); card("Profile",username); button("নাম পরিবর্তন",()->{EditText e=new EditText(this);e.setText(username);new AlertDialog.Builder(this).setTitle("নাম পরিবর্তন").setView(e).setPositiveButton("Save",(d,w)->{username=e.getText().toString();prefs.edit().putString("username",username).apply();show("Settings");}).setNegativeButton("Cancel",null).show();}); button("Admin Ads Manager (Local Demo)",()->admin()); button("Reset Demo Data",()->new AlertDialog.Builder(this).setMessage("সব ডেমো পয়েন্ট ও টাস্ক রিসেট করবেন?").setPositiveButton("Reset",(d,w)->{prefs.edit().clear().apply();points=0;username="User";adUrl="https://example.com";show("Home");}).setNegativeButton("Cancel",null).show()); card("About","Free Money v1.0.0 • Demo build • Real accounts, server sync, ad network and cash payments are not connected."); }
    private void admin(){ EditText pin=new EditText(this); pin.setHint("Admin PIN (demo: 2468)"); pin.setInputType(2); new AlertDialog.Builder(this).setTitle("Admin Access").setView(pin).setPositiveButton("Continue",(d,w)->{if(!pin.getText().toString().equals("2468")){Toast.makeText(this,"ভুল PIN",Toast.LENGTH_SHORT).show();return;} EditText url=new EditText(this);url.setText(adUrl);url.setHint("https://...");new AlertDialog.Builder(this).setTitle("Sponsor Advertisement URL").setMessage("এটি শুধু এই ডিভাইসে সংরক্ষিত হবে।").setView(url).setPositiveButton("Save",(dd,ww)->{adUrl=url.getText().toString().trim();prefs.edit().putString("ad_url",adUrl).apply();Toast.makeText(this,"লোকাল সেটিংস সংরক্ষিত",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}).setNegativeButton("Cancel",null).show(); }
    private void openAd(){ try{Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(adUrl)); startActivity(i);}catch(Exception e){Toast.makeText(this,"Sponsor URL সেট করা নেই",Toast.LENGTH_SHORT).show();} }
}
