# Free Money Android — Starter Project

এটি Free Money অ্যাপের একটি **চালানো যায় এমন লোকাল ডেমো সোর্স প্রজেক্ট**। সবুজ-কালো UI, প্রোফাইল নাম, ড্যাশবোর্ড, Daily Tasks, লোকাল Reward Points, Wallet, Message draft এবং Local Admin Ads Manager আছে।

## APK বানানোর নিয়ম (কম্পিউটারে Android Studio)
1. Android Studio ইনস্টল করুন: https://developer.android.com/studio
2. ZIP ফাইল Extract করুন।
3. Android Studio → Open → `FreeMoneyAndroid` ফোল্ডার নির্বাচন করুন।
4. Gradle Sync শেষ হলে Build → Build Bundle(s) / APK(s) → Build APK(s)।
5. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk` ফোল্ডারে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এই প্রজেক্টে এখনো অনলাইন সার্ভার/ডেটাবেস নেই। Login হলো লোকাল নাম-ভিত্তিক ডেমো, নিরাপদ অ্যাকাউন্ট নয়।
- পয়েন্ট শুধু এই ফোনে থাকে; এগুলো নন-ক্যাশ ডেমো পয়েন্ট, টাকা নয়।
- Messages ফোনে সেভ হয়, অ্যাডমিনের কাছে যায় না।
- Admin PIN `2468` কেবল ডেমো; প্রোডাকশনে এটি নিরাপদ নয়।
- Sponsor URL ডিফল্ট `https://example.com`; Admin Ads Manager থেকে বদলানো যায়।
- Ad network SDK, rewarded-ad verification, referral tracking, server-side admin panel, privacy policy, account security এবং withdrawal system যুক্ত করা হয়নি।

প্রকাশের আগে backend/API, secure authentication, admin role authorization, বিজ্ঞাপন নীতিমালা ও privacy policy বাস্তবায়ন এবং পরীক্ষা আবশ্যক।

## GitHub Actions দিয়ে অনলাইনে APK তৈরি (কম্পিউটার ছাড়াও সম্ভব, তবে GitHub অ্যাকাউন্ট লাগবে)
1. GitHub-এ নতুন repository তৈরি করুন এবং এই প্রজেক্টের ফাইল আপলোড করুন।
2. Actions ট্যাবে `Build Free Money APK` workflow চালু/Run workflow করুন।
3. Build সফল হলে workflow run-এর Artifacts থেকে `Free-Money-debug-APK` ZIP ডাউনলোড করুন; এর ভিতরে `app-debug.apk` থাকবে।
